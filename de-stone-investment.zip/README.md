# De-stone Coin Investment

This is a sample investment platform built with React.