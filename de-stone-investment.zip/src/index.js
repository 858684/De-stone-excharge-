import React from "react";
import ReactDOM from "react-dom/client";
import InvestmentSite from "./InvestmentSite";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <InvestmentSite />
  </React.StrictMode>
);